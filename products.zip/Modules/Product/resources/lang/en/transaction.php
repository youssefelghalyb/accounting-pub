<?php

return [
    // Page Titles
    'transactions' => 'Contract Transactions',
    'transaction' => 'Transaction',
    'transaction_list' => 'Transaction List',
    'add_transaction' => 'Add Transaction',
    'edit_transaction' => 'Edit Transaction',
    'view_transaction' => 'View Transaction',
    'transaction_details' => 'Transaction Details',
    'record_payment' => 'Record Payment',
    'payment_history' => 'Payment History',

    // Form Labels
    'contract' => 'Contract',
    'amount' => 'Amount',
    'payment_date' => 'Payment Date',
    'notes' => 'Notes',
    'receipt_file' => 'Receipt File',

    // Statistics
    'total_transactions' => 'Total Transactions',
    'total_amount' => 'Total Amount',
    'this_month_amount' => 'This Month',
    'this_year_amount' => 'This Year',

    // Actions
    'search' => 'Search transactions...',
    'filter_by_contract' => 'Filter by Contract',
    'filter_by_date' => 'Filter by Date Range',
    'all_contracts' => 'All Contracts',
    'date_from' => 'Date From',
    'date_to' => 'Date To',
    'download_receipt' => 'Download Receipt',
    'add_payment' => 'Add Payment',

    // Contract Info
    'contract_info' => 'Contract Information',
    'contract_information' => 'Contract Information',
    'contract_price' => 'Contract Price',
    'total_paid' => 'Total Paid',
    'outstanding_balance' => 'Outstanding Balance',
    'remaining' => 'Remaining',
    'payment_amount' => 'Payment Amount',
    'paid_on' => 'Paid On',
    'paid' => 'Paid',
    'view_receipt' => 'View Receipt',
    'payment_progress' => 'Payment Progress',

    // Messages
    'transaction_added' => 'Transaction added successfully',
    'transaction_updated' => 'Transaction updated successfully',
    'transaction_deleted' => 'Transaction deleted successfully',
    'no_transactions' => 'No transactions found',

    // Validation
    'contract_required' => 'Contract is required',
    'contract_invalid' => 'Invalid contract',
    'amount_required' => 'Amount is required',
    'amount_positive' => 'Amount must be greater than zero',
    'payment_date_required' => 'Payment date is required',
    'receipt_file_invalid' => 'Receipt file must be PDF or image format',
    'receipt_file_max_size' => 'Receipt file must not exceed 5MB',
    'amount_exceeds_contract_price' => 'The entered amount exceeds the contract price',
    'contract_fully_paid' => 'The contract has been fully paid',

    // Placeholders
    'select_contract' => 'Select contract',
    'enter_amount' => 'Enter amount',
    'select_payment_date' => 'Select payment date',
    'enter_notes' => 'Enter notes (optional)',
    'upload_receipt' => 'Upload receipt file (optional)',
];
