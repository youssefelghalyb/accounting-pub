<?php

namespace Modules\Product\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Modules\Product\Models\Author;
use Modules\Product\Http\Requests\StoreAuthorRequest;
use Modules\Product\Http\Requests\UpdateAuthorRequest;
use Modules\Product\Models\ContractTransaction;

class AuthorController extends Controller
{
    /**
     * Display a listing of authors.
     */
    public function index(Request $request)
    {
        $query = Author::query();

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('nationality', 'like', "%{$search}%")
                    ->orWhere('occupation', 'like', "%{$search}%");
            });
        }

        $authors = $query->orderBy('full_name')->paginate($request->get('per_page', 10))
            ->withQueryString();

        // Statistics
        $stats = [
            'total_authors' => Author::count(),
            'total_contracts' => \Modules\Product\Models\Contract::count(),
            'total_contract_value' => \Modules\Product\Models\Contract::sum('contract_price'),
        ];

        return view('product::authors.index', compact('authors', 'stats'));
    }

    /**
     * Show the form for creating a new author.
     */
    public function create()
    {
        return view('product::authors.create');
    }

    /**
     * Store a newly created author.
     */
    public function store(StoreAuthorRequest $request)
    {
        $validated = $request->validated();
        $validated['created_by'] = Auth::id();

        // Handle file upload
        if ($request->hasFile('id_image')) {
            $validated['id_image'] = $request->file('id_image')->store('authors/ids', 'public');
        }

        Author::create($validated);

        return redirect()
            ->route('product.authors.index')
            ->with('success', __('product::author.author_added'));
    }

    /**
     * Display the specified author.
     */
    public function show($id)
    {
        $author = Author::with('books.product', 'contracts.book')->findOrFail($id);

        // Get payment history
        $paymentHistory = $author->getAllTransactions();

        $transactions = ContractTransaction::whereHas('contract', function ($query) use ($author) {
            $query->where('author_id', $author->id);
        })->with('contract.book.product')->latest('payment_date')->get();

        // Calculate stats
        $stats = [
            'total_books' => $author->books()->count(),
            'total_contracts' => $author->contracts()->count(),
            'total_contract_value' => $author->total_contract_value,
            'total_paid' => $author->total_paid,
            'outstanding_balance' => $author->outstanding_balance,
        ];

        return view('product::authors.show', compact('author', 'paymentHistory', 'stats', 'transactions'));
    }

    /**
     * Show the form for editing the specified author.
     */
    public function edit($id)
    {
        $author = Author::findOrFail($id);

        return view('product::authors.edit', compact('author'));
    }

    /**
     * Update the specified author.
     */
    public function update(UpdateAuthorRequest $request, $id)
    {
        $author = Author::findOrFail($id);
        $validated = $request->validated();
        $validated['edited_by'] = Auth::id();

        // Handle file upload
        if ($request->hasFile('id_image')) {
            // Delete old file
            if ($author->id_image) {
                Storage::disk('public')->delete($author->id_image);
            }
            $validated['id_image'] = $request->file('id_image')->store('authors/ids', 'public');
        }

        $author->update($validated);

        return redirect()
            ->route('product.authors.index')
            ->with('success', __('product::author.author_updated'));
    }

    /**
     * Remove the specified author.
     */
    public function destroy($id)
    {
        $author = Author::findOrFail($id);

        // Check if author has books
        if ($author->books()->count() > 0) {
            return redirect()
                ->route('product.authors.index')
                ->with('error', __('product::author.cannot_delete_has_books'));
        }

        // Delete ID image if exists
        if ($author->id_image) {
            Storage::disk('public')->delete($author->id_image);
        }

        $author->delete();

        return redirect()
            ->route('product.authors.index')
            ->with('success', __('product::author.author_deleted'));
    }

    /**
     * Search authors for Select2
     */
    public function search(Request $request)
    {
        $query = Author::query();

        if ($request->filled('q')) {
            $search = $request->q;
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('nationality', 'like', "%{$search}%");
            });
        }

        $authors = $query->orderBy('full_name')
            ->paginate(10);

        return response()->json([
            'results' => $authors->map(function ($author) {
                return [
                    'id' => $author->id,
                    'text' => $author->full_name . ($author->nationality ? ' - ' . $author->nationality : '')
                ];
            }),
            'pagination' => [
                'more' => $authors->hasMorePages()
            ]
        ]);
    }

    /**
     * Quick store author for inline creation
     */
    public function quickStore(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:50',
            'nationality' => 'nullable|string|max:100',
        ]);

        $validated['created_by'] = Auth::id();

        $author = Author::create($validated);

        return response()->json([
            'success' => true,
            'message' => __('product::author.author_added'),
            'author' => [
                'id' => $author->id,
                'text' => $author->full_name . ($author->nationality ? ' - ' . $author->nationality : '')
            ]
        ]);
    }
}
